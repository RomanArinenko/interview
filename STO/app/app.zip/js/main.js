$(document).ready(function() {
 // SLIDER REVOLUTION JS-SETUP 

      jQuery('.tp-banner').revolution({
         delay:5000,
         startwidth:1170,
         startheight:350,
 
      });
});

